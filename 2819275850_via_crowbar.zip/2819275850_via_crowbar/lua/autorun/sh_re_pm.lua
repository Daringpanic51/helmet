player_manager.AddValidModel( "XVre Serpent's Hand", "models/player/xuvon/xuvon_sh_re_base.mdl" )
player_manager.AddValidHands( "XVre Serpent's Hand", "models/weapons/xuvon/xuvon_sh_re_arms.mdl", 0, "00000000" )

/*ya sosal menya ebali*/